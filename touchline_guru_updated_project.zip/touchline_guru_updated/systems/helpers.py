from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

import discord


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def parse_timestamp(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value)
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
    except ValueError:
        return None


def card_embed(card: dict, config, title_prefix: str = "") -> discord.Embed:
    rarity = config.rarity(card["rarity"]) or {"color": "#808080"}
    color = int(rarity["color"].lstrip("#"), 16)
    embed = discord.Embed(
        title=f"{title_prefix}{card['name']}",
        color=color,
    )

    details = [
        f"**Rarity:** {card['rarity']}",
        f"**Value:** {card['value']:,} coins",
    ]
    if card.get("club") and str(card["club"]).casefold() != "none":
        details.append(f"**Club:** {card['club']}")
    nationality = card.get("nation") or card.get("nationality")
    if nationality and str(nationality).casefold() != "none":
        details.append(f"**Nationality:** {nationality}")
    position = card.get("position")
    if position:
        details.append(f"**Position:** {position}")
    overall = card.get("overall", card.get("rating"))
    if overall is not None:
        details.append(f"**Overall:** {overall}")

    embed.description = "\n".join(details)
    embed.set_footer(text=f"Card ID: {card['id']}")
    embed.set_image(url=f"attachment://{Path(card['image']).name}")
    return embed


def local_card_file(base_dir: Path, card: dict) -> discord.File:
    return discord.File(
        base_dir / card["image"],
        filename=Path(card["image"]).name,
    )


async def send_card(
    interaction: discord.Interaction,
    card: dict,
    config,
    base_dir: Path,
    content=None,
):
    embed = card_embed(card, config)
    file = local_card_file(base_dir, card)
    if interaction.response.is_done():
        await interaction.followup.send(content=content, embed=embed, file=file)
    else:
        await interaction.response.send_message(content=content, embed=embed, file=file)
