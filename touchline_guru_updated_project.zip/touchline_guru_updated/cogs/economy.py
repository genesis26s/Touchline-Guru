from __future__ import annotations

import random
from datetime import timedelta

import discord
from discord import app_commands
from discord.ext import commands

from systems.helpers import (
    card_embed,
    local_card_file,
    parse_timestamp,
    utc_now,
)


class ClaimRewardView(discord.ui.View):
    """Persistent buttons for resolving a daily claim card."""

    def __init__(self, bot):
        super().__init__(timeout=None)
        self.bot = bot

    async def _resolve(self, interaction: discord.Interaction, action: str) -> None:
        db = await self.bot.db.connect()
        try:
            await db.execute("BEGIN IMMEDIATE")
            cur = await db.execute(
                """
                SELECT id, card_id, card_value, message_id
                FROM pending_claims
                WHERE user_id=? AND status='pending'
                ORDER BY id DESC LIMIT 1
                """,
                (interaction.user.id,),
            )
            pending = await cur.fetchone()

            if (
                not pending
                or pending["message_id"] is None
                or pending["message_id"] != interaction.message.id
            ):
                await db.rollback()
                return await interaction.response.send_message(
                    "This claim is no longer available to you.",
                    ephemeral=True,
                )

            if action == "keep":
                await db.execute(
                    """
                    INSERT INTO inventory(user_id, card_id, quantity)
                    VALUES(?,?,1)
                    ON CONFLICT(user_id, card_id)
                    DO UPDATE SET quantity=quantity+1
                    """,
                    (interaction.user.id, pending["card_id"]),
                )
                status = "kept"
                kind = "daily_card_kept"
                amount = 0
                details = f"Daily claim card: {pending['card_id']}"
            else:
                await db.execute(
                    "UPDATE users SET balance=balance+? WHERE user_id=?",
                    (pending["card_value"], interaction.user.id),
                )
                status = "sold"
                kind = "daily_card_sale"
                amount = pending["card_value"]
                details = f"Daily claim card sold: {pending['card_id']}"

            cur = await db.execute(
                """
                UPDATE pending_claims
                SET status=?
                WHERE id=? AND status='pending'
                """,
                (status, pending["id"]),
            )
            if cur.rowcount != 1:
                await db.rollback()
                return await interaction.response.send_message(
                    "This claim has already been resolved.",
                    ephemeral=True,
                )

            await db.execute(
                """
                INSERT INTO transactions(user_id, kind, amount, details)
                VALUES(?,?,?,?)
                """,
                (interaction.user.id, kind, amount, details),
            )
            await db.commit()

        except Exception:
            await db.rollback()
            raise
        finally:
            await db.close()

        embed = interaction.message.embeds[0].copy()
        if action == "keep":
            embed.description = (embed.description or "") + "\n\n**Card kept and added to your inventory.**"
        else:
            embed.description = (
                (embed.description or "")
                + f"\n\n**Card sold for {pending['card_value']:,} coins.**"
            )
        await interaction.response.edit_message(embed=embed, view=None)

    @discord.ui.button(
        label="Keep",
        style=discord.ButtonStyle.success,
        custom_id="daily_claim:keep",
    )
    async def keep_button(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button,
    ):
        await self._resolve(interaction, "keep")

    @discord.ui.button(
        label="Sell",
        style=discord.ButtonStyle.danger,
        custom_id="daily_claim:sell",
    )
    async def sell_button(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button,
    ):
        await self._resolve(interaction, "sell")


class Economy(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        # timeout=None and stable custom IDs allow pending claim buttons to
        # continue working after a bot restart.
        self.bot.add_view(ClaimRewardView(bot))

    @app_commands.command(
        name="claim",
        description="Claim your daily football card and coins.",
    )
    async def claim(self, interaction: discord.Interaction):
        cfg = self.bot.config.economy.get("daily_claim", {})
        if not cfg.get("enabled", True):
            return await interaction.response.send_message(
                "Daily claims are currently disabled.",
                ephemeral=True,
            )

        card_cfg = cfg.get("card_reward", {})
        card_enabled = card_cfg.get("enabled", True)
        card = None
        if card_enabled:
            card = self.bot.config.pick_card(card_cfg.get("rarities"))
            if not card:
                return await interaction.response.send_message(
                    "A daily card cannot be awarded because no eligible cards are configured.",
                    ephemeral=True,
                )

        currency_cfg = cfg.get("currency_reward", {})
        low = int(currency_cfg.get("min", 500))
        high = int(currency_cfg.get("max", 1500))
        if low < 0 or high < low:
            return await interaction.response.send_message(
                "The daily currency reward is configured incorrectly.",
                ephemeral=True,
            )
        coins = random.randint(low, high)
        cooldown = timedelta(hours=int(cfg.get("cooldown_hours", 24)))

        db = await self.bot.db.connect()
        pending_id = None
        now = utc_now()
        try:
            await db.execute("BEGIN IMMEDIATE")
            await db.execute(
                "INSERT OR IGNORE INTO users(user_id) VALUES(?)",
                (interaction.user.id,),
            )

            cur = await db.execute(
                "SELECT last_claim_at FROM users WHERE user_id=?",
                (interaction.user.id,),
            )
            user = await cur.fetchone()
            last_claim = parse_timestamp(user["last_claim_at"] if user else None)

            if last_claim and now < last_claim + cooldown:
                remaining = last_claim + cooldown - now
                hours, remainder = divmod(int(remaining.total_seconds()), 3600)
                minutes = remainder // 60
                await db.rollback()
                return await interaction.response.send_message(
                    f"You have already claimed. Try again in **{hours}h {minutes}m**.",
                    ephemeral=True,
                )

            cur = await db.execute(
                """
                SELECT id FROM pending_claims
                WHERE user_id=? AND status='pending'
                LIMIT 1
                """,
                (interaction.user.id,),
            )
            if await cur.fetchone():
                await db.rollback()
                return await interaction.response.send_message(
                    "Resolve your previous claim using its Keep or Sell button first.",
                    ephemeral=True,
                )

            await db.execute(
                """
                UPDATE users
                SET balance=balance+?, last_claim_at=?
                WHERE user_id=?
                """,
                (coins, now.isoformat(), interaction.user.id),
            )
            details = f"Daily card: {card['id']}" if card else "Daily currency reward"
            await db.execute(
                """
                INSERT INTO transactions(user_id, kind, amount, details)
                VALUES(?,?,?,?)
                """,
                (interaction.user.id, "daily_claim", coins, details),
            )

            if card:
                cur = await db.execute(
                    """
                    INSERT INTO pending_claims(user_id, card_id, card_value, coins_reward)
                    VALUES(?,?,?,?)
                    """,
                    (interaction.user.id, card["id"], card["value"], coins),
                )
                pending_id = cur.lastrowid

            await db.commit()

        except Exception:
            await db.rollback()
            raise
        finally:
            await db.close()

        if not card:
            embed = discord.Embed(
                title="Daily claim successful",
                description=f"You received **{coins:,} coins**.",
                color=discord.Color.gold(),
            )
            return await interaction.response.send_message(embed=embed)

        embed = card_embed(card, self.bot.config)
        embed.description = (
            f"**Daily reward:** {coins:,} coins\n\n"
            + (embed.description or "")
            + "\n\nChoose whether to keep or sell this card."
        )
        await interaction.response.send_message(
            embed=embed,
            file=local_card_file(self.bot.base_dir, card),
            view=ClaimRewardView(self.bot),
        )
        message = await interaction.original_response()

        db = await self.bot.db.connect()
        try:
            await db.execute(
                "UPDATE pending_claims SET message_id=? WHERE id=? AND status='pending'",
                (message.id, pending_id),
            )
            await db.commit()
        finally:
            await db.close()

    @app_commands.command(name="balance", description="View your coin balance.")
    async def balance(
        self,
        interaction: discord.Interaction,
        member: discord.Member | None = None,
    ):
        target = member or interaction.user
        user = await self.bot.db.get_user(target.id)
        currency_name = self.bot.config.economy.get("currency_name", "coins")
        embed = discord.Embed(
            title=f"{target.display_name}'s balance",
            description=f"**{user['balance']:,} {currency_name}**",
            color=discord.Color.gold(),
        )
        await interaction.response.send_message(embed=embed)

    @app_commands.command(
        name="leaderboard",
        description="Show the richest Touchline Guru players.",
    )
    async def leaderboard(self, interaction: discord.Interaction):
        db = await self.bot.db.connect()
        try:
            cur = await db.execute(
                """
                SELECT user_id, balance
                FROM users
                ORDER BY balance DESC
                LIMIT 10
                """
            )
            rows = await cur.fetchall()
        finally:
            await db.close()

        if not rows:
            return await interaction.response.send_message("No players have balances yet.")

        lines = [
            f"**{index}.** <@{row['user_id']}> — {row['balance']:,} coins"
            for index, row in enumerate(rows, start=1)
        ]
        embed = discord.Embed(
            title="Coin leaderboard",
            description="\n".join(lines),
            color=discord.Color.gold(),
        )
        await interaction.response.send_message(embed=embed)


async def setup(bot):
    await bot.add_cog(Economy(bot))
