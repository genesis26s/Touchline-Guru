TOUCHLINE GURU - UPDATED FILES

Replace the matching files in your existing project with the files in this archive.
The config folder contains your supplied cards.json, settings.json, rarities.json,
and economy.json, plus the updated packs.json.

IMPORTANT BEFORE STARTING
1. Keep your existing .env file. Do not replace it with this archive.
2. Keep your existing assets/cards/ images. This archive does not contain card artwork.
3. Install your existing requirements (discord.py 2.x, aiosqlite, python-dotenv).
4. Start the bot. Database.initialize() creates the new tables automatically.
5. Sync application commands. If using DEV_GUILD_ID, commands sync to that guild.

FEATURES
- /claim grants coins immediately and presents one card embed with persistent Keep/Sell buttons.
- Keep adds the card to inventory; Sell credits the card's configured value.
- Claim decisions are stored in SQLite and buttons survive bot restarts.
- /packs is a dropdown shop. Selecting a pack purchases and opens it immediately.
- Golden Pack: 200,000 coins; Silver Pack: 30,000 coins. Both contain 3 cards.
- /marketplace shows a shared rotation of up to three distinct cards, refreshed every two hours.
- Marketplace purchase price equals the card's configured value.
- The old /market player-listing group and its buy/list/cancel commands are removed.
- Card embeds now read overall/rating and nation/nationality fields.

CURRENT CARD-POOL LIMITATIONS
- Your supplied cards.json currently has only two Gold cards. The marketplace therefore
  displays two cards until at least one more card is added. It will never duplicate a card
  within one rotation.
- Your Silver Pack cannot be opened until at least one Silver card exists in cards.json.
- Add new cards with unique IDs, a rarity already defined in rarities.json, a non-negative
  integer value, and an existing local image path.

DATABASE
- Existing user balances, inventory, transactions, and pack history are preserved.
- New pending_claims and marketplace_rotation tables are created automatically.
- The old market_listings table is retained but no longer used; no destructive migration occurs.

NOTES
- Pack selection purchases immediately; there is no separate /open command.
- Marketplace card selection opens a preview; Buy Card confirms the purchase.
- Marketplace stock is shared across players, but each player may purchase a card for themselves.
