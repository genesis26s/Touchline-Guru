from __future__ import annotations

import json
import random
from datetime import timedelta

import discord
from discord import app_commands
from discord.ext import commands

from systems.helpers import card_embed, local_card_file, parse_timestamp, utc_now


ROTATION_LENGTH = timedelta(hours=2)
ROTATION_SIZE = 3


class Marketplace(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def _pick_rotation(self) -> list[dict]:
        """Pick up to three distinct cards using configured rarity weights."""
        remaining = list(self.bot.config.cards.values())
        selected = []

        while remaining and len(selected) < ROTATION_SIZE:
            available_rarities = {
                card["rarity"].casefold() for card in remaining
            }
            rarity_options = [
                rarity
                for key, rarity in self.bot.config.rarities.items()
                if key in available_rarities
            ]
            if not rarity_options:
                break

            chosen_name = random.choices(
                rarity_options,
                weights=[rarity["weight"] for rarity in rarity_options],
                k=1,
            )[0]["name"]
            same_rarity = [
                card for card in remaining
                if card["rarity"].casefold() == chosen_name.casefold()
            ]
            chosen_card = random.choice(same_rarity)
            selected.append(chosen_card)
            remaining = [
                card for card in remaining if card["id"] != chosen_card["id"]
            ]

        return selected

    async def get_rotation(self) -> tuple[list[dict], str]:
        db = await self.bot.db.connect()
        try:
            await db.execute("BEGIN IMMEDIATE")
            cur = await db.execute(
                "SELECT cards_json, expires_at FROM marketplace_rotation WHERE id=1"
            )
            row = await cur.fetchone()
            now = utc_now()
            expires = parse_timestamp(row["expires_at"]) if row else None

            existing_ids = []
            if row:
                try:
                    existing_ids = json.loads(row["cards_json"])
                except (TypeError, json.JSONDecodeError):
                    existing_ids = []

            existing_valid = (
                bool(existing_ids)
                and all(card_id in self.bot.config.cards for card_id in existing_ids)
            )

            if not row or not expires or now >= expires or not existing_valid:
                selected = self._pick_rotation()
                ids = [card["id"] for card in selected]
                expires = now + ROTATION_LENGTH
                await db.execute(
                    """
                    INSERT INTO marketplace_rotation(id, cards_json, expires_at, updated_at)
                    VALUES(1,?,?,?)
                    ON CONFLICT(id) DO UPDATE SET
                        cards_json=excluded.cards_json,
                        expires_at=excluded.expires_at,
                        updated_at=excluded.updated_at
                    """,
                    (json.dumps(ids), expires.isoformat(), now.isoformat()),
                )
            else:
                selected = [self.bot.config.cards[card_id] for card_id in existing_ids]

            await db.commit()
            return selected, expires.isoformat()
        except Exception:
            await db.rollback()
            raise
        finally:
            await db.close()

    async def purchase_card(
        self,
        user_id: int,
        card_id: str,
        expected_expiry: str,
    ) -> tuple[bool, str]:
        card = self.bot.config.cards.get(card_id)
        if not card:
            return False, "That card is no longer configured."

        db = await self.bot.db.connect()
        try:
            await db.execute("BEGIN IMMEDIATE")
            cur = await db.execute(
                "SELECT cards_json, expires_at FROM marketplace_rotation WHERE id=1"
            )
            rotation = await cur.fetchone()
            now = utc_now()

            if not rotation:
                await db.rollback()
                return False, "The marketplace rotation has changed. Reopen /marketplace."

            expires = parse_timestamp(rotation["expires_at"])
            try:
                current_ids = json.loads(rotation["cards_json"])
            except (TypeError, json.JSONDecodeError):
                current_ids = []

            if (
                not expires
                or now >= expires
                or rotation["expires_at"] != expected_expiry
                or card_id not in current_ids
            ):
                await db.rollback()
                return False, "The marketplace rotation has changed. Reopen /marketplace."

            await db.execute(
                "INSERT OR IGNORE INTO users(user_id) VALUES(?)",
                (user_id,),
            )
            cur = await db.execute(
                "SELECT balance FROM users WHERE user_id=?",
                (user_id,),
            )
            user = await cur.fetchone()
            price = int(card["value"])

            if not user or user["balance"] < price:
                await db.rollback()
                return False, f"You need **{price:,} coins** to buy this card."

            await db.execute(
                "UPDATE users SET balance=balance-? WHERE user_id=?",
                (price, user_id),
            )
            await db.execute(
                """
                INSERT INTO inventory(user_id, card_id, quantity)
                VALUES(?,?,1)
                ON CONFLICT(user_id, card_id)
                DO UPDATE SET quantity=quantity+1
                """,
                (user_id, card_id),
            )
            await db.execute(
                """
                INSERT INTO transactions(user_id, kind, amount, details)
                VALUES(?,?,?,?)
                """,
                (user_id, "marketplace_purchase", -price, card_id),
            )
            await db.commit()
            return True, f"Purchased **{card['name']}** for **{price:,} coins**."
        except Exception:
            await db.rollback()
            raise
        finally:
            await db.close()

    @app_commands.command(
        name="marketplace",
        description="Browse the rotating card marketplace.",
    )
    async def marketplace(self, interaction: discord.Interaction):
        cards, expiry = await self.get_rotation()
        embed = discord.Embed(
            title="Touchline Guru Marketplace",
            description=(
                "Browse the three cards currently available. "
                "Cards rotate every two hours and cost their configured value."
            ),
            color=discord.Color.gold(),
        )
        embed.set_footer(text="Select See the Marketplace to browse.")
        await interaction.response.send_message(
            embed=embed,
            view=MarketplaceEntryView(self, expiry),
            ephemeral=True,
        )


class MarketplaceEntryView(discord.ui.View):
    def __init__(self, cog: Marketplace, expiry: str):
        super().__init__(timeout=180)
        self.cog = cog
        self.expiry = expiry

    @discord.ui.button(
        label="See the Marketplace",
        style=discord.ButtonStyle.primary,
    )
    async def see_marketplace(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button,
    ):
        cards, expiry = await self.cog.get_rotation()
        if not cards:
            return await interaction.response.edit_message(
                content="No cards are configured for the marketplace yet.",
                embed=None,
                view=None,
            )
        embed = discord.Embed(
            title="Available Marketplace Cards",
            description=(
                "Select a card to inspect it and purchase it.\n"
                "Prices match each card's configured value."
            ),
            color=discord.Color.gold(),
        )
        await interaction.response.edit_message(
            embed=embed,
            view=MarketplaceSelectView(self.cog, cards, expiry),
        )


class MarketplaceSelect(discord.ui.Select):
    def __init__(self, cog: Marketplace, cards: list[dict], expiry: str):
        self.cog = cog
        self.expiry = expiry
        self.cards_by_id = {card["id"]: card for card in cards}
        options = [
            discord.SelectOption(
                label=str(card["name"])[:100],
                value=card["id"],
                description=f"{card['rarity']} · {card['value']:,} coins"[:100],
            )
            for card in cards[:25]
        ]
        super().__init__(
            placeholder="Select a card",
            min_values=1,
            max_values=1,
            options=options,
        )

    async def callback(self, interaction: discord.Interaction):
        card = self.cards_by_id.get(self.values[0])
        if not card:
            return await interaction.response.send_message(
                "That card is no longer available.",
                ephemeral=True,
            )
        embed = card_embed(card, self.cog.bot.config)
        embed.description = (
            (embed.description or "")
            + f"\n\n**Marketplace price: {card['value']:,} coins**"
        )
        await interaction.response.edit_message(
            embed=embed,
            attachments=[local_card_file(self.cog.bot.base_dir, card)],
            view=MarketplacePurchaseView(
                self.cog,
                card["id"],
                interaction.user.id,
                self.expiry,
            ),
        )


class MarketplaceSelectView(discord.ui.View):
    def __init__(self, cog: Marketplace, cards: list[dict], expiry: str):
        super().__init__(timeout=180)
        self.add_item(MarketplaceSelect(cog, cards, expiry))


class MarketplacePurchaseView(discord.ui.View):
    def __init__(
        self,
        cog: Marketplace,
        card_id: str,
        owner_id: int,
        expiry: str,
    ):
        super().__init__(timeout=180)
        self.cog = cog
        self.card_id = card_id
        self.owner_id = owner_id
        self.expiry = expiry

    @discord.ui.button(
        label="Buy Card",
        style=discord.ButtonStyle.success,
    )
    async def buy_card(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button,
    ):
        if interaction.user.id != self.owner_id:
            return await interaction.response.send_message(
                "This purchase menu belongs to another player.",
                ephemeral=True,
            )

        success, message = await self.cog.purchase_card(
            interaction.user.id,
            self.card_id,
            self.expiry,
        )
        if not success:
            return await interaction.response.send_message(
                message,
                ephemeral=True,
            )

        embed = interaction.message.embeds[0].copy()
        embed.description = (embed.description or "") + "\n\n**Purchase successful.**"
        await interaction.response.edit_message(
            content=message,
            embed=embed,
            view=None,
        )


async def setup(bot):
    await bot.add_cog(Marketplace(bot))
