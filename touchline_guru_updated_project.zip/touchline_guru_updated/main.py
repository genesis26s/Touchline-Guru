from __future__ import annotations

import logging
import os
from pathlib import Path

import discord
from discord.ext import commands
from dotenv import load_dotenv

from systems.config_manager import ConfigManager
from systems.database import Database

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

(BASE_DIR / "logs").mkdir(exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(BASE_DIR / "logs" / "touchline-guru.log", encoding="utf-8"),
    ],
)
log = logging.getLogger("touchline-guru")


class TouchlineGuru(commands.Bot):
    def __init__(self) -> None:
        super().__init__(command_prefix="!", intents=discord.Intents.default())
        self.base_dir = BASE_DIR
        self.config = ConfigManager(BASE_DIR)
        self.db = Database(BASE_DIR / "data" / "touchline.db")

    async def setup_hook(self) -> None:
        await self.db.initialize()
        await self.config.load_all()

        for extension in (
            "cogs.economy",
            "cogs.cards",
            "cogs.packs",
            "cogs.inventory",
            "cogs.marketplace",
            "cogs.admin",
        ):
            await self.load_extension(extension)
            log.info("Loaded %s", extension)

        dev_guild = os.getenv("DEV_GUILD_ID", "").strip()
        if dev_guild.isdigit():
            guild = discord.Object(id=int(dev_guild))
            self.tree.copy_global_to(guild=guild)
            synced = await self.tree.sync(guild=guild)
            log.info("Synced %d commands to development guild %s", len(synced), dev_guild)
        else:
            synced = await self.tree.sync()
            log.info("Synced %d global application commands", len(synced))

    async def on_ready(self) -> None:
        log.info("Ready as %s (%s)", self.user, self.user.id if self.user else "unknown")
        await self.change_presence(activity=discord.Game(name="Touchline Guru | /claim"))


bot = TouchlineGuru()


@bot.tree.error
async def on_app_command_error(
    interaction: discord.Interaction, error: discord.app_commands.AppCommandError
) -> None:
    log.error(
        "Slash command error",
        exc_info=(type(error), error, error.__traceback__),
    )
    message = "Something went wrong. Please try again later."
    if isinstance(error, discord.app_commands.MissingPermissions):
        message = "You do not have permission to use that command."
    elif isinstance(error, discord.app_commands.CommandOnCooldown):
        message = f"Please wait {error.retry_after:.1f} seconds before trying again."
    if interaction.response.is_done():
        await interaction.followup.send(message, ephemeral=True)
    else:
        await interaction.response.send_message(message, ephemeral=True)


def main() -> None:
    token = os.getenv("DISCORD_TOKEN", "").strip()
    if not token:
        raise SystemExit("DISCORD_TOKEN is missing. Copy .env.example to .env and add your token.")
    bot.run(token, log_handler=None)


if __name__ == "__main__":
    main()
