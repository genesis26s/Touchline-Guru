import discord
from discord import app_commands
from discord.ext import commands


class Admin(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(
        name="reload_config",
        description="Reload cards, rarities, packs, and economy JSON files.",
    )
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def reload_config(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        try:
            await self.bot.config.load_all()
        except Exception as exc:
            await interaction.followup.send(
                "Configuration reload failed. The previous configuration is still active.\n"
                f"```text\n{str(exc)[:1500]}\n```",
                ephemeral=True,
            )
            return
        await interaction.followup.send(
            f"Configuration reloaded successfully.\n"
            f"Cards: **{len(self.bot.config.cards)}** · "
            f"Rarities: **{len(self.bot.config.rarities)}** · "
            f"Packs: **{len(self.bot.config.packs)}**",
            ephemeral=True,
        )


async def setup(bot):
    await bot.add_cog(Admin(bot))
