import discord
from discord import app_commands
from discord.ext import commands

from systems.helpers import send_card


class Cards(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="card", description="Inspect a footballer card by its card ID.")
    async def card(self, interaction: discord.Interaction, card_id: str):
        card = self.bot.config.cards.get(card_id)
        if not card:
            return await interaction.response.send_message(
                "I couldn't find that card ID.",
                ephemeral=True,
            )
        await interaction.response.defer()
        await send_card(interaction, card, self.bot.config, self.bot.base_dir)


async def setup(bot):
    await bot.add_cog(Cards(bot))
