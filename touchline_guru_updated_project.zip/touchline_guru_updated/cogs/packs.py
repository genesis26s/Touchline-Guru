from __future__ import annotations

import json
import discord
from discord import app_commands
from discord.ext import commands

from systems.helpers import card_embed, local_card_file


class PackSelect(discord.ui.Select):
    def __init__(self, bot):
        self.bot = bot
        packs = list(bot.config.packs.values())[:25]
        options = [
            discord.SelectOption(
                label=str(pack["name"])[:100],
                value=pack["id"],
                description=f"{pack['price']:,} coins · {pack['cards_per_pack']} cards"[:100],
            )
            for pack in packs
        ]
        super().__init__(
            placeholder="Select a pack to buy",
            min_values=1,
            max_values=1,
            options=options,
        )

    async def callback(self, interaction: discord.Interaction):
        pack = self.bot.config.packs.get(self.values[0])
        if not pack:
            return await interaction.response.send_message(
                "That pack is no longer configured. Reopen /packs.",
                ephemeral=True,
            )

        eligible = self.bot.config.cards_for_rarities(pack["rarities"])
        if not eligible:
            return await interaction.response.send_message(
                "This pack has no eligible cards configured yet. Please contact an administrator.",
                ephemeral=True,
            )

        cards = []
        for _ in range(pack["cards_per_pack"]):
            card = self.bot.config.pick_card(pack["rarities"])
            if card is None:
                return await interaction.response.send_message(
                    "This pack is not configured correctly.",
                    ephemeral=True,
                )
            cards.append(card)

        db = await self.bot.db.connect()
        try:
            await db.execute("BEGIN IMMEDIATE")
            await db.execute(
                "INSERT OR IGNORE INTO users(user_id) VALUES(?)",
                (interaction.user.id,),
            )
            cur = await db.execute(
                "SELECT balance FROM users WHERE user_id=?",
                (interaction.user.id,),
            )
            user = await cur.fetchone()
            if not user or user["balance"] < pack["price"]:
                await db.rollback()
                return await interaction.response.send_message(
                    f"You need **{pack['price']:,} coins** to buy the {pack['name']}.",
                    ephemeral=True,
                )

            await db.execute(
                "UPDATE users SET balance=balance-? WHERE user_id=?",
                (pack["price"], interaction.user.id),
            )
            for card in cards:
                await db.execute(
                    """
                    INSERT INTO inventory(user_id, card_id, quantity)
                    VALUES(?,?,1)
                    ON CONFLICT(user_id, card_id)
                    DO UPDATE SET quantity=quantity+1
                    """,
                    (interaction.user.id, card["id"]),
                )
            await db.execute(
                """
                INSERT INTO transactions(user_id, kind, amount, details)
                VALUES(?,?,?,?)
                """,
                (interaction.user.id, "pack_purchase", -pack["price"], pack["id"]),
            )
            await db.execute(
                """
                INSERT INTO pack_history(user_id, pack_id, cards_json, paid)
                VALUES(?,?,?,?)
                """,
                (
                    interaction.user.id,
                    pack["id"],
                    json.dumps([card["id"] for card in cards]),
                    pack["price"],
                ),
            )
            await db.commit()
        except Exception:
            await db.rollback()
            raise
        finally:
            await db.close()

        embeds = [
            card_embed(card, self.bot.config, title_prefix=f"{pack['name']} · ")
            for card in cards[:10]
        ]
        attachments = [
            local_card_file(self.bot.base_dir, card)
            for card in cards[:10]
        ]
        content = (
            f"**{pack['name']} opened!** You received **{len(cards)} card(s)** "
            f"for **{pack['price']:,} coins**."
        )
        if len(cards) > 10:
            content += "\nOnly the first 10 card images are displayed."
        await interaction.response.edit_message(
            content=content,
            embeds=embeds,
            attachments=attachments,
            view=None,
        )


class PackShopView(discord.ui.View):
    def __init__(self, bot):
        super().__init__(timeout=180)
        self.add_item(PackSelect(bot))


class Packs(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="packs", description="Browse and buy card packs.")
    async def packs(self, interaction: discord.Interaction):
        packs = list(self.bot.config.packs.values())
        if not packs:
            return await interaction.response.send_message(
                "There are no packs configured.",
                ephemeral=True,
            )
        lines = [
            f"**{pack['name']}** — **{pack['price']:,} coins** · "
            f"{pack['cards_per_pack']} cards"
            for pack in packs
        ]
        embed = discord.Embed(
            title="Card Pack Shop",
            description="Select a pack to buy.\n\n" + "\n".join(lines),
            color=discord.Color.gold(),
        )
        await interaction.response.send_message(
            embed=embed,
            view=PackShopView(self.bot),
            ephemeral=True,
        )


async def setup(bot):
    await bot.add_cog(Packs(bot))
