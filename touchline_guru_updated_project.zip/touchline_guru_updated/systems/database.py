from __future__ import annotations

import aiosqlite
from pathlib import Path


SCHEMA = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY,
    balance INTEGER NOT NULL DEFAULT 0 CHECK(balance >= 0),
    last_claim_at TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS inventory (
    user_id INTEGER NOT NULL,
    card_id TEXT NOT NULL,
    quantity INTEGER NOT NULL DEFAULT 0 CHECK(quantity >= 0),
    PRIMARY KEY (user_id, card_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    kind TEXT NOT NULL,
    amount INTEGER NOT NULL,
    details TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS pack_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    pack_id TEXT NOT NULL,
    cards_json TEXT NOT NULL,
    paid INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Retained for compatibility with existing databases; the old player-listing
-- marketplace commands no longer use this table.
CREATE TABLE IF NOT EXISTS market_listings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    seller_id INTEGER NOT NULL,
    card_id TEXT NOT NULL,
    quantity INTEGER NOT NULL CHECK(quantity > 0),
    price_each INTEGER NOT NULL CHECK(price_each > 0),
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS pending_claims (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    card_id TEXT NOT NULL,
    card_value INTEGER NOT NULL CHECK(card_value >= 0),
    coins_reward INTEGER NOT NULL CHECK(coins_reward >= 0),
    message_id INTEGER,
    status TEXT NOT NULL DEFAULT 'pending'
        CHECK(status IN ('pending', 'kept', 'sold', 'cancelled')),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_one_pending_claim_per_user
ON pending_claims(user_id) WHERE status = 'pending';

CREATE TABLE IF NOT EXISTS marketplace_rotation (
    id INTEGER PRIMARY KEY CHECK(id = 1),
    cards_json TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_transactions_user
ON transactions(user_id, id DESC);

CREATE INDEX IF NOT EXISTS idx_pending_claims_user
ON pending_claims(user_id, status);
"""


class Database:
    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    async def connect(self) -> aiosqlite.Connection:
        """Create and configure a new SQLite connection."""
        db = await aiosqlite.connect(self.path, timeout=5.0)
        db.row_factory = aiosqlite.Row
        try:
            await db.execute("PRAGMA foreign_keys = ON")
            await db.execute("PRAGMA busy_timeout = 5000")
            await db.execute("PRAGMA journal_mode = WAL")
            return db
        except Exception:
            await db.close()
            raise

    async def initialize(self) -> None:
        db = await self.connect()
        try:
            await db.executescript(SCHEMA)
            await db.commit()
        finally:
            await db.close()

    async def ensure_user(self, user_id: int) -> None:
        db = await self.connect()
        try:
            await db.execute(
                "INSERT OR IGNORE INTO users(user_id) VALUES (?)",
                (user_id,),
            )
            await db.commit()
        finally:
            await db.close()

    async def get_user(self, user_id: int):
        await self.ensure_user(user_id)
        db = await self.connect()
        try:
            cursor = await db.execute(
                "SELECT * FROM users WHERE user_id = ?",
                (user_id,),
            )
            return await cursor.fetchone()
        finally:
            await db.close()

    async def get_inventory(self, user_id: int):
        await self.ensure_user(user_id)
        db = await self.connect()
        try:
            cursor = await db.execute(
                """
                SELECT card_id, quantity
                FROM inventory
                WHERE user_id = ? AND quantity > 0
                ORDER BY card_id
                """,
                (user_id,),
            )
            return await cursor.fetchall()
        finally:
            await db.close()
