import discord
from discord import app_commands
from discord.ext import commands


class Inventory(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="inventory", description="View your football card collection.")
    async def inventory(
        self,
        interaction: discord.Interaction,
        member: discord.Member | None = None,
    ):
        target = member or interaction.user
        rows = await self.bot.db.get_inventory(target.id)
        if not rows:
            return await interaction.response.send_message(
                f"**{target.display_name}** doesn't own any cards yet.",
                ephemeral=(member is None),
            )

        lines = []
        total_cards = 0
        total_value = 0
        for row in rows:
            card = self.bot.config.cards.get(row["card_id"])
            total_cards += row["quantity"]
            if not card:
                lines.append(
                    f"`{row['card_id']}` × {row['quantity']} *(card config missing)*"
                )
                continue
            total_value += card["value"] * row["quantity"]
            lines.append(
                f"**{card['name']}** · {card['rarity']} · "
                f"×{row['quantity']} · {card['value']:,} coins"
            )

        embed = discord.Embed(
            title=f"{target.display_name}'s inventory",
            description="\n".join(lines[:25]),
            color=discord.Color.gold(),
        )
        embed.add_field(name="Cards owned", value=f"{total_cards:,}")
        embed.add_field(name="Collection value", value=f"{total_value:,} coins")
        if len(lines) > 25:
            embed.set_footer(
                text=f"Showing 25 of {len(lines)} card types. Pagination can be added later."
            )
        await interaction.response.send_message(
            embed=embed,
            ephemeral=(member is None),
        )


async def setup(bot):
    await bot.add_cog(Inventory(bot))
